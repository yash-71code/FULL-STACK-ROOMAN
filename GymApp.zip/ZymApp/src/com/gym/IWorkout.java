package com.gym;

public interface IWorkout {
	void addWorkout(Workout workout, int index);
	Workout[] displayWorkouts();

}
