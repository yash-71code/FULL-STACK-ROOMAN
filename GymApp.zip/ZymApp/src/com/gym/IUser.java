package com.gym;

public interface IUser {
	String register(User user,int index);
	boolean login(String username,String password);

}
