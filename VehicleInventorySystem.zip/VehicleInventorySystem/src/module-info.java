/**
 * 
 */
/**
 * 
 */
module VehicleInventorySystem {
}