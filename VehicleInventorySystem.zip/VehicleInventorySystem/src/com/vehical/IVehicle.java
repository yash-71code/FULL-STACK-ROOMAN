package com.vehical;

interface IVehicle {
    void displayVehicles();
    void sortBy(String criteria);
}